import 'package:flutter/material.dart';
import 'package:parallax_animation/parallax_animation.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

void main() {
  runApp(const ParallaxApp());
}

class ParallaxApp extends StatefulWidget {
  const ParallaxApp({Key? key}) : super(key: key);

  @override
  State<ParallaxApp> createState() => _ParallaxAppState();
}

class _ParallaxAppState extends State<ParallaxApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const ParallaxSample(),
    );
  }
}

class ParallaxSample extends StatefulWidget {
  const ParallaxSample({Key? key}) : super(key: key);

  @override
  State<ParallaxSample> createState() => _ParallaxSampleState();
}

class _ParallaxSampleState extends State<ParallaxSample> {
  final videoLinkList = <String>[
    'https://media.istockphoto.com/id/1196852310/video/male-lion-walking.mp4?s=mp4-640x640-is&k=20&c=CUbQfxz3UsvQN-ff09qNNHyJVVzB2KHJx1Nc73JH0jE=',
    'https://cdn.videvo.net/videvo_files/video/premium/video0313/large_watermarked/601-2_601-8211_preview.mp4',
    'https://joy1.videvo.net/videvo_files/video/free/2019-11/large_watermarked/190301_1_25_06_preview.mp4',
    'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Parallax sample"),
        ),
        body: ParallaxArea(
            child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              for (var index = 0; index < videoLinkList.length; index++)
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: ChildWidegt(
                    index: index,
                    videoLink: videoLinkList[index],
                  ),
                ),
            ],
          ),
        )));
  }
}

class ChildWidegt extends StatefulWidget {
  final String videoLink;
  final int index;
  const ChildWidegt({required this.index, required this.videoLink});

  @override
  State<ChildWidegt> createState() => _ChildWidegtState();
}

class _ChildWidegtState extends State<ChildWidegt> {
  late VideoPlayerController _controller;
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.network(widget.videoLink)
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return ParallaxWidget(
      overflowWidthFactor: 3,
      inverted: true,
      background: _controller.value.isInitialized
              ? AspectRatio(
                  aspectRatio: 10 / 9,
                  child: VideoPlayer(_controller),
                )
              : const CircularProgressIndicator(),
      child: VisibilityDetector(
        key: Key(widget.videoLink),
        onVisibilityChanged: (VisibilityInfo info) {
            print(
                "${widget.index} : ${info.visibleFraction} of my widget is visible");
          },
        child: Center(
              child: Text(
                "PAGE ${widget.index + 1}",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 40,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
      ),
    );
  }
}
