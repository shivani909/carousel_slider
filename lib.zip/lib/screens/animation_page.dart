import 'package:flutter/material.dart';

class AnimationPage extends StatefulWidget {
  const AnimationPage({ Key? key }) : super(key: key);

  @override
  State<AnimationPage> createState() => _AnimationPageState();
}

class _AnimationPageState extends State<AnimationPage> {
  @override
  Widget build(BuildContext context) {
    return  SingleChildScrollView(
      child: Column(
        children: [
          
        ],
      ),
    );
  }
}